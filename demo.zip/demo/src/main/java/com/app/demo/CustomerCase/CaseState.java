package com.app.demo.CustomerCase;

public enum CaseState {
    APPROVED,
    REJECTED,
    PENDING
}
